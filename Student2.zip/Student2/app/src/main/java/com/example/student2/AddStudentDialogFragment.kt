package com.example.student2

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.fragment.app.DialogFragment

class AddStudentDialogFragment: DialogFragment() {

    private var photoImageView: ImageView? = null
    private var selectedImageUri: Uri? = null
    private val pickImage = 1
    private var id = 0

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            val inflater = requireActivity().layoutInflater
            val view = inflater.inflate(R.layout.dialog_add_student, null)

            photoImageView = view.findViewById(R.id.photoImageView)

            view.findViewById<Button>(R.id.selectPhotoButton).setOnClickListener {
                val photoPickerIntent = Intent(Intent.ACTION_PICK)
                photoPickerIntent.type = "image/*"
                startActivityForResult(photoPickerIntent, pickImage)
            }

            builder.setView(view)
                .setPositiveButton("Сохранить") { dialog, id ->
                    val name = view.findViewById<EditText>(R.id.fullNameEditText).text.toString()
                    val email = view.findViewById<EditText>(R.id.emailEditText).text.toString()
                    val group = view.findViewById<EditText>(R.id.groupEditText).text.toString()
                    if (selectedImageUri != null) {
                        (activity as MainActivity).addStudent(Student(selectedImageUri!!,this.id, name, email, group))
                        this.id += 1
                    }
                }
                .setNegativeButton("Отмена") { dialog, id ->
                    dialog.cancel()
                }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.data
            photoImageView?.setImageURI(selectedImageUri)

        }
    }
}
