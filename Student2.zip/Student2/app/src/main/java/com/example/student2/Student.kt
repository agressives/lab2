package com.example.student2

import android.net.Uri
import android.os.Parcel
import android.os.Parcelable

data class Student(
    val photoUri: Uri?,
    val id: Int,
    var fullName: String?,
    var email: String?,
    val group: String?
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readParcelable(Uri::class.java.classLoader),
        parcel.readInt(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeParcelable(photoUri, flags)
        parcel.writeInt(id)
        parcel.writeString(fullName)
        parcel.writeString(email)
        parcel.writeString(group)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Student> {
        override fun createFromParcel(parcel: Parcel): Student {
            return Student(parcel)
        }

        override fun newArray(size: Int): Array<Student?> {
            return arrayOfNulls(size)
        }
    }
}
