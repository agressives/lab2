package com.example.student2

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.EditText
import androidx.fragment.app.DialogFragment

class EditStudentDialogFragment : DialogFragment() {

    private var student: Student? = null

    companion object {
        fun newInstance(student: Student): EditStudentDialogFragment {
            val fragment = EditStudentDialogFragment()
            val args = Bundle()
            args.putParcelable("student", student)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        student = arguments?.getParcelable("student")
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            val inflater = requireActivity().layoutInflater
            val view = inflater.inflate(R.layout.dialog_edit_student, null)

            val nameEditText: EditText = view.findViewById(R.id.nameEditText)
            val emailEditText: EditText = view.findViewById(R.id.emailEditText)
            nameEditText.setText(student?.fullName)
            emailEditText.setText(student?.email)

            builder.setView(view)
                .setPositiveButton("Сохранить") { dialog, id ->
                    student?.fullName = nameEditText.text.toString()
                    student?.email = emailEditText.text.toString()
                    (activity as MainActivity).updateStudent(student!!)
                }
                .setNeutralButton("Удалить") { dialog, id ->
                    (activity as MainActivity).deleteStudent(student!!)
                }
                .setNegativeButton("Отмена") { dialog, id ->
                    dialog.cancel()
                }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}
