import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class StudentEntity(
    @PrimaryKey val id: Int,
    var fullName: String?,
    var email: String?,
    val group: String?
)