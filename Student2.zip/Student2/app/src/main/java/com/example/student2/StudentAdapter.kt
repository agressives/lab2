package com.example.student2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class StudentAdapter(private val students: List<Student>, private val activity: MainActivity) : RecyclerView.Adapter<StudentAdapter.StudentViewHolder>() {

    var onItemClick: ((Student) -> Unit)? = null

    class StudentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        val idView: TextView = itemView.findViewById(R.id.idText)
        val nameView: TextView = itemView.findViewById(R.id.nameText)
        val emailView: TextView = itemView.findViewById(R.id.emailText)
        val groupView: TextView = itemView.findViewById(R.id.groupText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.student_item, parent, false)
        return StudentViewHolder(view)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        val student = students[position]
        with(holder) {
            imageView.setImageURI(student.photoUri)
            idView.text = student.id.toString()
            nameView.text = student.fullName
            emailView.text = student.email
            groupView.text = student.group
        }

        holder.itemView.setOnClickListener {
            (activity).onStudentSelected(student!!)
        }

    }

    override fun getItemCount() = students.size
}
