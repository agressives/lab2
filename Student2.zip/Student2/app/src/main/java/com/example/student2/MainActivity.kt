package com.example.student2

import AppDatabase
import StudentEntity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {
    private val groups = mutableSetOf<String>()


    fun onStudentSelected(student: Student) {
        // Здесь код обработки выбора студента, например:
        EditStudentDialogFragment.newInstance(student).show(supportFragmentManager, "editStudentDialog")
    }
    lateinit var database: AppDatabase

    var students = mutableListOf<Student>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        students = mutableListOf(
            Student("1".toUri(), 1, "Иван Иванов", "ivan@example.com", "Группа 1")
        )

        //database = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "MyDatabase").build()


        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = StudentAdapter(students, this@MainActivity)
        val addButton: Button = findViewById(R.id.addStudentButton)
        addButton.setOnClickListener {
            AddStudentDialogFragment().show(supportFragmentManager, "addStudentDialog")
        }
        recyclerView.adapter = adapter
        this.groups.add("Все")
        setupSpinnerListener()
        updateSpinner()

    }

    private fun setupSpinnerListener() {
        val groupSpinner: Spinner = findViewById(R.id.groupSpinner)
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        groupSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedGroup = parent.getItemAtPosition(position) as String
                Log.e("AAAA", "Selected group: $selectedGroup")
                Log.e("AAAA", students.size.toString())
                val filteredStudents = if (selectedGroup == "Все") {
                    students
                } else {
                    students.filter { it.group == selectedGroup }
                }
                recyclerView.adapter = StudentAdapter(filteredStudents, this@MainActivity)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Ничего не делаем, если ничего не выбрано
            }
        }
    }

    fun addStudent(student: Student) {
        // Логика добавления студента в список и обновления RecyclerView
        students.add(student)
        groups.add(student.group!!)
        Log.e("AAAA", students.size.toString())
        updateSpinner()
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = StudentAdapter(students, this@MainActivity)
//        CoroutineScope(Dispatchers.IO).launch {
//            database.studentDao().insertStudent(StudentEntity(student.id, student.fullName, student.email, student.group))
//        }

    }

    private fun updateSpinner() {
        val groupSpinner : Spinner = findViewById(R.id.groupSpinner)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups.toList())
        groupSpinner.adapter = adapter
    }

    fun deleteStudent(student: Student) {
        // Логика удаления студента из списка и обновления RecyclerView
        students.remove(student)
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = StudentAdapter(students, this@MainActivity)
//            CoroutineScope(Dispatchers.IO).launch {
//                database.studentDao().deleteStudent(StudentEntity(student.id, student.fullName, student.email, student.group))
//            }
    }

    fun updateStudent(student: Student) {
        // Логика обновления студента в списке и обновления RecyclerView
        val index = students.indexOfFirst { it.id == student.id }
        if (index != -1) {
            students[index] = student
            val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
            recyclerView.adapter = StudentAdapter(students, this@MainActivity)
//            CoroutineScope(Dispatchers.IO).launch {
//                database.studentDao().updateStudent(StudentEntity(student.id, student.fullName, student.email, student.group))
//            }
        }

    }

}
